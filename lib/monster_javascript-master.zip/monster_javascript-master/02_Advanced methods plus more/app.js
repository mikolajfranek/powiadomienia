//numbers
console.log("#numbers");
let num_one = 100.525;
let num_two = "100";
console.log(num_one.toFixed(2));
console.log(Number(num_two));
console.log(parseInt(num_two));
console.log(num_two);
var a = new Number('123'); // a === 123 is false
var b = Number('123'); // b === 123 is true
console.log(a instanceof Number); //true
console.log(b instanceof Number); //false

//string
console.log("#string");
let myString = "    some code is here, but other is not      ";
console.log(myString.length);
console.log(myString.trim());
console.log(myString.toUpperCase());
console.log(myString.toLowerCase());
console.log(myString.split('')); //all charakters in array
console.log(myString.charAt(7));
console.log(myString[7]);
console.log(myString.slice(7)); //cut string from index to end
console.log(myString.slice(7,18));
console.log(myString.substring(7,18)); //stop at 18 but not include //cannot accept negative index 
console.log(myString.substr(7,18)); //18 is maximum length to return
console.log(myString.replace('is', 'are')); //only one element is replaced
console.log(myString.lastIndexOf('is')); //return position
console.log(myString.indexOf('is')); //return position
console.log(myString.search('is')); // same as indexof return position

//math
console.log("#math");
console.log(Math.floor(5.96)); //5
console.log(Math.floor(5.02)); //5
console.log(Math.floor(5)); //5
console.log(Math.floor(-5.05)); //-6
console.log(Math.ceil(4)); //4
console.log(Math.ceil(4.002)); //5
console.log(Math.ceil(-7.002)); //-7

function getRandomInt(max){
    return Math.floor(Math.random()*Math.floor(max));
}
//Math.random() - inclusive of 0 but not 1
console.log(getRandomInt(3)); //0,1,2
console.log(getRandomInt(1)); //0
console.log(Math.random());
function getRandomIntBeetween(min, max){
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random()* (max-min)) + min;
}
console.log(getRandomIntBeetween(10,20));

//Includes
console.log("#includes");
var array1 = [1,2,3];
console.log(array1.includes(2)); //true
console.log(array1.includes(4)); //false

const excludeNumber = [10,15,7,1,4,2,5];
function generateRandom(min, max){
    let num = Math.floor(Math.random() * (max-min+1)) + min;
    return excludeNumber.includes(num) ? generateRandom(min, max) : num;
}
for(let x = 0; x < 20; x++){
    let min = 1;
    let max = 15;
    let num = generateRandom(min,max);
    console.log(num);
}

//array random message
const myArray = ["Hello", "Welcome", "bye bye"];
let temp = randomItem(myArray);
let mes = document.createTextNode(temp);
document.body.appendChild(mes);
function randomItem(array){
    return array[Math.floor(Math.random() * array.length)];
}

//background color
document.body.style.backgroundColor = randomColor();
function randomColor(){
    return "#" + Math.random().toString(16).substr(-6);
}

//the same as $(document).ready(function(){});
window.addEventListener("DOMContentLoaded", function(event){
    console.log('Dom fully loaded and parsed');
});
window.addEventListener("keydown", function(event){
   console.log(event.key + " " + event.keyCode); 
});

//keyboard mover
let player = {
    speed: 100,
    x: 100,
    y: 100
};
document.addEventListener("DOMContentLoaded", build);
document.addEventListener("keydown", function(event){
   let key = event.keyCode;
   switch(key){
    case 37:
        player.x -= player.speed;
        break;
    case 38:
        player.y -= player.speed;
        break;
    case 39:
        player.x += player.speed;
        break;
    case 40:
        player.y += player.speed;
        break;
   }
   player.el.style.top = player.y + "px";
   player.el.style.left = player.x + "px";
});
function build(){
    player.el = document.createElement("div");
    player.x = 100;
    player.y = 100;
    player.el.style.position = "absolute";
    player.el.style.width = "100px";
    player.el.style.height = "100px";
    player.el.style.backgroundColor = "red";
    player.el.style.top = player.y + "px";
    player.el.style.left = player.x + "px";
    document.body.appendChild(player.el);
}

//date
//JavaScript count months from 0 to 11
console.log("#date");
var today = new Date();
console.log(today);
today = Date.now();
console.log(today);
var birthday = new Date('December 17, 1995 03:23:22');
console.log(birthday);
birthday = new Date('1995-12-17T03:23:22');
console.log(birthday);
birthday = new Date(1995, 11, 17);
console.log(birthday);
birthday = new Date(1995, 11, 17, 3, 23, 22); //year, month, day, hour, minute, second
console.log(birthday);
let d = new Date(0); //Start January 01, 1970
console.log(d);
console.log(d.toString());
console.log(d.toUTCString());
console.log(d.toDateString());
d = new Date("2020-12-31");
console.log(d);
d = new Date("2020/12/31");
console.log(d);
console.log(d.getDate());//day  
console.log(d.getDay()); //number of week
console.log(d.getTime()); //numeric timestamp
d = new Date();
console.log(d.getMilliseconds()); //according to local time?
console.log(d.getUTCMilliseconds()); //according to universal time?
d.setFullYear(2025);
console.log(d);

console.log("#parse");
/* Parse and stringify */
//parse json string to object
const json = '{"first":"John", "last":"Doe"}';
let obj = JSON.parse(json);
console.log(obj);
console.log(obj.first);

console.log("#stringify");
//stringify object to json string
const myObj = {
    first: "John",
    last: "Doe"
};
console.log(myObj);
let myNewString = JSON.stringify(myObj);
console.log(myNewString);

//localstorage
console.log("#localstorage");
localStorage.setItem('myName', "John");
let me = localStorage.getItem('myName');
console.log(me);
localStorage.removeItem('myName');
//localStorage.clear(); //clear all

if(localStorage.getItem('num')){
    let count = localStorage.getItem('num');
    count = Number(count);
    count++;
    localStorage.setItem('num', count);
}else{
    localStorage.setItem('num', 1);
}
console.log(localStorage.getItem('num'));

//getBoundingClientRect
let el = document.querySelector("div");
var rect = el.getBoundingClientRect();
console.log(rect);

//timers
const interval = window.setInterval(myCallback, 500, 'interval');
const timeout = window.setTimeout(myCallback, 500, 'setTimeout');
console.log(interval);
console.log(timeout);
function myCallback(message){
   console.log(message);
}
function stopInterval(){
   clearInterval(interval);
}
let x = 0;
function step(){
   x++;
   el.style.transform = 'translateX(' + x + 'px)';
   if(x > 100){
      stopInterval();
   }
   if(x < 300){
      window.requestAnimationFrame(step);
   }
}
//tells the browser that you wish to perform an animation
//and request that the browser call a specified funciton to
//update an animation before the next repaint
window.requestAnimationFrame(step);

//challenge timers
let y = 10;
const secInterval = window.setInterval(counter, 1000);
el.style.color = "white";
el.style.fontSize = "32px";
function counter(){
   el.textContent = y;
   y--;
   if(y < 0){
      clearInterval(secInterval);
   }
}

//encode decode uri component
let url = window.location.href;
let encodeurl = encodeURIComponent(url); //hex
let decodeurl = decodeURIComponent(encodeurl);
console.log(encodeurl);
console.log(decodeurl);
function constainsEncodedComponents(x){
   return (decodeURI(x) !== decodeURIComponent(x));
}
let url2 = url + "?x=text&user=john doe";
console.log(url2);
console.log(encodeURI(url2));
console.log(encodeURIComponent(url2));
console.log(constainsEncodedComponents(encodeURI(url2)));
console.log(constainsEncodedComponents(encodeURIComponent(url2)));

//regex
let myStr = "HelloWorld JavaScript 123 sometestemail@gmail.com this works I love javaScript 44 sample@email.com";
let reg = /(\w+)\s(\w+)/;
/*
\d any digit charakter
\w alpthanumeric charakter
\s any whitespace charakter
\D a charakter that is not a digit
\W a nonalphanumeric charakter
\S a nonwhitespace charakter
+ one or more times
* zero or more times
*/
let temp1 = myStr.replace(reg, 'TEST1,TEST2');
let temp5 = myStr.replace("World", "People");
console.log(temp1);
console.log(temp5);
console.log(myStr.match(/J/));
console.log(myStr.match(/J/gi));
//g - looking in the whole string and returning all matches
//i - ignore case
console.log(/JavaScript/.test(myStr));
console.log(/[0-9]/.test(myStr));
let temp4 = /\d+/.exec(myStr);
console.log(temp4);
console.log(temp4.index);
let myArr = ['one', 'two', 'three', 'four'];
let temp2 = myArr.toString();
let temp3 = myArr.join('....');
console.log(temp2);
console.log(temp3);
console.log(myStr.search(/javascript/)); //return index
console.log(myStr.search(/javascript/gi));
console.log(myStr.match(/javascript/gi));
//regex for email
let expression = /([A-Za-z0-9._-]+@[A-Za-z0-9._-]+\.[A-Za-z0-9._-]+)/g;
console.log(myStr.match(expression));

//prototype
function Person(first, last){
   this.firstName = first;
   this.lastName = last;
}
Person.prototype.fullName = function(){
   return this.firstName + ' ' + this.lastName; 
};
const me_person = new Person('John', 'Doe');
console.log(me_person);
console.log(me_person.fullName());

//chalange date
Date.prototype.addDays = function(days){
   return new Date(this.valueOf() + days * 864e5); // 864e5 - milisecond of day
};
console.log(new Date().addDays(7));

//try catch
const ele = document.querySelector('#input_field');
const button = document.querySelector('#button_field');
button.addEventListener('click', tester);

function tester(){   
   try{
      let num = ele.value;
      console.log(num);
      if(num=="") throw 'no value';
      if(isNaN(num)) throw 'not a number';
      num = Number(num);
      if(num > 5) throw 'over 5';
      if(num < 5) throw 'under 5';
      document.querySelector('div').textContent = num;
   }catch(error){
      console.log(error);
      document.querySelector('div').textContent = error;
   }finally{
      console.log('this will always show');
      ele.value = '';
   }
}

//xHR 
var xhr = new XMLHttpRequest();
var url_chuck = "https://api.chucknorris.io/jokes/random";
xhr.onreadystatechange = function(){
  console.log('xhr:' + xhr.readyState);
  if(xhr.readyState == 4 && xhr. status == 200){
      console.log('xhr: ' + xhr.response);
      let joke = JSON.parse(xhr.response);
      console.log('xhr: ' + joke.value);
  }
};
xhr.open("GET", url_chuck);
xhr.send();
console.log('xhr: ' + xhr);

//fetch
fetch(url_chuck)
.then(function(response){
   return response.json();
})
.then(function(data){
   console.log("fetch: " + data.value);
});

//challange - add new table with data, filtred data
 let url_todos = 'https://jsonplaceholder.typicode.com/todos';
 fetch(url_todos)
 .then(function(response){
   return response.json();
 })
 .then(function(data){
   let new_t = document.createElement('table');
   for(let x = 0; x < data.length; ++x){
      let new_tr = document.createElement('tr');
      let new_td = document.createElement('td');
      if(data[x].completed){
         new_td.style.color = "white";
      }else{
         new_td.style.color = "yellow";
      }
      new_td.textContent = data[x].id + ' ' + data[x].title;
      new_tr.appendChild(new_td);
      new_t.appendChild(new_tr);
   }
   document.body.appendChild(new_t);
 });
