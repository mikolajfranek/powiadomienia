document.addEventListener('DOMContentLoaded', function(){
   const score = document.querySelector('.score');
   const output = document.querySelector('.output');
   const buttons = document.querySelectorAll('button');
   const options = ['Rock', 'Paper', 'Scissors'];
   let count_score = {user:0, computer:0};
   let results = {
      Rock: {Rock:0, Paper:-1, Scissors:1},
      Paper: {Rock:1, Paper:0, Scissors:-1},
      Scissors: {Rock:-1, Paper:1, Scissors:0}
      };
   
   buttons.forEach(function(item){
      item.addEventListener('click', playGame);
   });
   
   function playGame(event){
      let user_quess = event.target.innerText;
      let computer_quess = options[Math.floor(Math.random()*3)];
      
      let message = `(user) ${user_quess} vs computer ${computer_quess}<br/>`;
      switch(results[user_quess][computer_quess]){
         case 1:
            count_score.user++;
            message += 'User win';
            break;
         case -1:
            count_score.computer++;
            message += 'Computer win';
            break;
         case 0:
            message += 'Draw';
            break;
         default:
            message += 'Some error';
            break;
      }
      output.innerHTML = message;
      score.innerHTML = `(user): ${count_score.user} (computer): ${count_score.computer}`;
   }
   
   console.log('app is loaded');
});