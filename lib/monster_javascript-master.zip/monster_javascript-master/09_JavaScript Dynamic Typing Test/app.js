document.addEventListener('DOMContentLoaded', function(){
   const wording = ["Do you like JavaScript as much as I do?",
                    "Hope you are having fun this is a simple game you can make.",
                    "Source code is included so you can create your own version of this challenge."];
   
   function getRandomInt(number){
      return Math.floor(Math.random()*Math.floor(number));
   }
   
   let startTime, endTime;
   const message = document.querySelector('.message');
   const playText = document.querySelector('textarea');
   const button = document.querySelector('button');
   
   button.addEventListener('click', function(){
      if(this.innerText == 'Start'){
         playText.disabled = false;
         playText.value = '';
         playGame();
      }else if(this.innerText == 'Done'){
         playText.disabled = true;
         endGame();
      }
   });
   
   function playGame(){
      message.innerText = wording[getRandomInt(wording.length)];
      startTime = new Date().getTime();
      button.innerText = 'Done';
   }
   
   function endGame(){
      endTime = new Date().getTime();
      button.innerText = 'Start';
      let total_seconds = (endTime - startTime)/1000;
      let result_text = playText.value;
      let count_words = result_text.split(' ').length;
      let speed = Math.round((count_words / total_seconds) * 60, 2);
      let final_message = `You typed at ${speed} words per minute`;
      if(result_text != message.innerText){
         final_message += '<br/>' + message.innerText + '<br/>';
         final_message += compareWords(message.innerText, result_text);
      }
      message.innerHTML = final_message;
   }
   
   function compareWords(str1, str2){
      let words1 = str1.split(' ');
      let words2 = str2.split(' ');
      let words_good = 0;
      words1.forEach(function(item, index){
         words_good += item == words2[index];
      });
      return `${words_good} correct out of ${words1.length}`;
   }
   
   console.log('app is loaded');
});