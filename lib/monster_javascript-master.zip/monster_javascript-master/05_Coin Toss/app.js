document.addEventListener('DOMContentLoaded', function(){
   const output = document.querySelector('.output');
   const buttons = document.querySelectorAll('button');
   const coinArray = ['Heads', 'Tails'];
   let score  = [0,0];
   
   buttons.forEach(function(item){
      item.addEventListener('click', tossCoin);
   });
   
   function tossCoin(event){
      let computerToss = Math.floor(Math.random()*2);
      
      let userGuess = event.target.innerText;
      let computerGuess = coinArray[computerToss];
      
      
      let message = `Computer select ${computerGuess}<br/>`;
      if(userGuess == computerGuess){
         score[0]++;
         message += 'User win';
      }else{
         score[1]++;
         message += 'Computer win';
      }
      output.innerHTML = `${message} <br/> User: ${score[0]} <br/> Computer: ${score[1]}`;
   }
   
   console.log('app is loaded');
});
