let userName = window.prompt("What is your name");
let message = `Welcome ${userName}`; //backticks
console.log(message);
