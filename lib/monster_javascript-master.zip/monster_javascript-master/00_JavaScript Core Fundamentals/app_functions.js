let output = "HelloWorld";
let counter = 0;
welcome(output);
welcome(output);
welcome(output);

function welcome(message){
    counter++;
    let temp = counter + " times run";
    console.log(message);
    console.log(temp);
}

let myNum = 50;
addTen(myNum);

//console.log(addTen()); ok
//function declaration
function addTen(myNum = 5){
    //myNum = myNum || 5;
    //myNum = typeof myNum !== 'undefined' ? myNum : 5;
    myNum += 10;
    console.log(myNum); //60
}
console.log(myNum); //50

//console.log(multiply(10,20)); error
//function expression
let multiply = function(a, b){
    return a*b;
}
console.log(multiply(10,20));