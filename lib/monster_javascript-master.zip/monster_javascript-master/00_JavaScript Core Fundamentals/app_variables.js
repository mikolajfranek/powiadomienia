var a = "JavaScript"; //this was a test variable
window.alert(a);
console.log(a);
a = "Hello world";
window.alert(a);
console.log(a);
/*
 * I enjoy working with JavaScript
 */