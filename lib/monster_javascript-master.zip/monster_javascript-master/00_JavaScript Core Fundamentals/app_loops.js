let x = 0;
while(x < 5){
    x++;
    console.log("While loop - count at " + x);
}

let i = 0;
do{
    i+=1;
    console.log("Do while loop - count at " + i);
}while(i < 5);


for(let w = 0; w < 100; w++){
    console.log("For loop - count at " + w);
    if(w === 3){
        console.log("continue");
        continue;
    }
    if(w === 5){
        console.log("break");
        break;
    }
    console.log("For loop - count at " + w);    
}

const myWork = [];
for(let i = 1; i < 10; i++){
    let stat = i%2 ? true: false;
    let value = {name: `Lesson ${i}`, status: stat};
    myWork.push(value);
}
console.log("#array");
console.log(myWork);

const result = myWork.filter(function(element){
    return element.status;
});
console.log("#filter");
console.log(result);


const myArray = ['a', 'b', 'c'];
console.log("#foreach");
myArray.forEach(function(item, index, array){
   console.log(item, index, array); 
});

console.log("#foreach");
for(let element in myArray){
    console.log(element, myArray[element]);   
}

console.log("#foreach");
for(let w = 0; w < myArray.length; w++){
    console.log(myArray[w]);
}

console.log("#foreach");
const obj = {a:1, b:2, c:3};
for(let property in obj){
    console.log(property, obj[property]);
}

console.log("#map");
const numArray = [77, 44, 2, 162, 18, 244, 71];
let mapArray = numArray.map(function(x){
    return x * 2;
});
console.log(mapArray);