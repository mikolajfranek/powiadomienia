function person(firstName, lastName){
  this.first = firstName;
  this.last = lastName;
  this.age = 44;
  this.alive = false;
  this.executed_in_definition = executed_in_definition_or_call("It executed in definition"); //it call a funciton when object is creating - ACCESS to 'this.*' as parameter
  this.executed_in_call = executed_in_definition_or_call; //is a function reference
  this.message = (function(){ // the same as executed_in_call, but in difference form
    console.log("Greate job " + this.first  + " " + this.last);
    return "Return cash";
  });
}
  
function executed_in_definition_or_call(info){
  console.log(info);
  return "Return value";
}

const object = new person("Mikolaj", "Kowalski");
console.log(object);
console.log(object['alive']);
console.log(object.executed_in_call("It called the function"));
console.log(object.message());