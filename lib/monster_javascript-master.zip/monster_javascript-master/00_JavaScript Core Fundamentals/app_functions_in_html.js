//document must be loaded
const btns = document.querySelectorAll('button');
btns[0].onclick = message_one;
btns[1].onclick = message_two;
btns[2].onclick = message_three;

let var1, var2, var3;
var1 = var2 = var3 = 0;

function message_one(){
    var1++;
    message();
}
function message_two(){
    var2++;
    message();
}
function message_three(){
    var3++;
    message();
}
function message(){
    console.log(var1 + " " + var2 + " "  + var3);
}

let a = 5;
function test(){
    //console.log(a); //error - can't access lexical declaration before initialization
    let a = 5;
}
test();