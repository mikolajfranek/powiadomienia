(function(){
    console.log("Welcome IIFE");
})();

(function(){
    let firstName = "Mikolaj";
})();

let result = (function(){
    let firstName = "Mikolaj";
    return firstName;
})();
console.log(result);

(function(firstName){
    console.log("My name is: " + firstName);
})("Mike");

result = (function(){
    return "Hello world";
});
console.log(result());