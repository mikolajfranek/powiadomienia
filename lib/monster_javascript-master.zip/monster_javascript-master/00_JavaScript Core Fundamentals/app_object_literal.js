const person = {
  first: "Mikolaj",
  last: "Kowalski",
  age: 44,
  alive: true,
  executed_in_definition: executed_in_definition_or_call("It executed in definition"), //it call a funciton when object is creating - DON'T access to 'this.*' as parameter
  executed_in_call: executed_in_definition_or_call, //is a function reference
  message: (function(){ // the same as executed_in_call, but in difference form
    console.log("Greate job " + this.first  + " " + this.last);
    return "Return cash";
  })
};
  
function executed_in_definition_or_call(info){
  console.log(info);
  return "Return value";
}

console.log(person);
console.log(person['alive']);
console.log(person.executed_in_call("It called the function"));
console.log(person.message());