var test10 = (function(x){
    return x * 5;
});
const test11 = (x) => x * 5;
const test12 = (x) => {
    return x * 5;
};
console.log(test10(5));
console.log(test11(5));
console.log(test12(5));

