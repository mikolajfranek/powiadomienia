let secretNumber = 5;

guesser();
function guesser(){
    let guess = prompt("Guess the number");
    let guessNumber = Number(guess);
    if(guessNumber === secretNumber){
        console.log("Correct!");
        return;
    }else{
        let message = guessNumber < secretNumber ? "higher" : "lower";
        console.log("Wrong, try again. Try " + message);
        guesser();
    }
}