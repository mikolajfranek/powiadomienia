const theList = ['FirstName', "LastName", true, 52, null, undefined, {name:"John", last:"Doe"}, ['one', 'two']];
theList[2] = false;
console.log(theList[6].name);
console.log(theList[7][1]);
console.log(theList);

var myArray = ['FirstName', "LastName", true, 52];
console.log("#length");
console.log(myArray.length);//length

console.log("#indexOf");
console.log(myArray.indexOf(52)); //return index of element

console.log("#indexOf"); 
console.log(myArray.indexOf("LastNameX")); //return -1

console.log("#splice"); //remove element on the position
console.log(myArray.splice(myArray.indexOf(52), 1)); //return array of deleted

console.log("#isArray");
console.log(Array.isArray(myArray));

console.log("#slice - copy of array");
var copyOfArray = myArray.slice();
console.log(copyOfArray);

console.log("#myArray");
console.log(myArray);

var val1 = myArray.push('test'); //add value on the ends of array - return index of element
console.log("#myArray");
console.log(myArray);
console.log("#val1");
console.log(val1);

var val2 = myArray.pop(); //remove from end array - last element - return value of element
console.log("#myArray");
console.log(myArray);
console.log("#val2");
console.log(val2);

var val3 = myArray.shift(); //remove from front array - first element - return value of element
console.log("#myArray");
console.log(myArray);
console.log("#val3");
console.log(val3);

var val4 = myArray.unshift("Make me first"); //return new lenght
console.log("#myArray");
console.log(myArray);
console.log("#val4");
console.log(val4);

const myArray1 = ["a", "hello", 4, 8, 2, "world", "javascript", "course", 99, 1];
const myArray2 = [5, 12, 8, 130, 44];

console.log("#myArray1");
console.log(myArray1);
myArray1.sort();
console.log("#sort");
console.log(myArray1);

myArray1.reverse();
console.log("#reverse");
console.log(myArray1);

console.log("#indexOf");
console.log(myArray1.indexOf(50));
if(myArray1.indexOf(50) === -1){
   console.log("not found");
}

let newArray = myArray1.concat(myArray2);
console.log("#concat");
console.log(newArray);

let found = myArray2.find(function(element){
   return element > 10;
});
console.log("#find");
console.log(found);

const numArray = [77, 44, 2, 162, 18, 244, 71];
let result = numArray.filter(function(element){
    return element > 75;
});
console.log("#filter");
console.log(result);