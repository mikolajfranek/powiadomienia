var a = true;
var b = 100;
var c = "Hello World";
var d = null;
var e;
var f = Symbol("value");
console.log(f);

let temp;
temp = 10;
temp = String(10);
temp = String([1,2,3,4]);
console.log(temp);
temp = (100).toString();
temp = Number('10');
temp = Number(true);
temp = Number([1,2,3,4]); //nan
console.log(temp);

let myNum = "5";
myNum = Number(myNum);
console.log(myNum);
console.log(typeof myNum);

let sa = Number("5");
let sb = Number("10");
console.log(sa+sb);

console.log("5" + 5); //55
console.log("10" - 5); //5
console.log("hello" - "world");