//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Lexical_grammar
var message;
console.log(message);
message = null;
console.log(message);
var myLight = false;
console.log(myLight);
myLight = true;
if(myLight){
    console.log(myLight);
}
var score1, score2, score3, score4;
var a = "Hello";
var b = 10;
var c = false;
console.log(a);

let myMessage = "Welcome";
let moreStuff;
if(true){
    let myMessage = "New one";
    moreStuff = "Yes the content is there";
    console.log(myMessage);
}
console.log(moreStuff);
console.log(myMessage);

let counter1 = 5;
counter1++;
console.log(counter1);
const counter2 = 10;
counter2++;
console.log(counter2);