document.addEventListener("DOMContentLoaded", function(){
   const button = document.querySelector('button');
   const input = document.querySelector('input');
   const output = document.querySelector('.output');
   button.addEventListener('click', function(){
      let cost = Number(input.value);
      let procent = Number(0.333333);
      let tip = (cost*procent).toFixed(2);
      
      let new_h1 = document.createElement('h1');
      let text_h1 = document.createTextNode(`You should tip $${tip} on $${cost}`);
      new_h1.appendChild(text_h1);
      
      output.innerHTML = '';
      output.appendChild(new_h1);
      console.log(output);
   });
   console.log('app is loaded');
});