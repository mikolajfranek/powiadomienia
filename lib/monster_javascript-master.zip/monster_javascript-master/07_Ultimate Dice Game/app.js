document.addEventListener('DOMContentLoaded', function(){
   const button = document.querySelector('button');
   const player1 = document.querySelector('#player1');
   const player2 = document.querySelector('#player2');
   const output = document.querySelector('.output');
   const dice = [[5], [1,9], [1,5,9], [1,3,7,9], [1,3,5,7,9],[1,3,4,6,7,9]];
   
   function roll(max){
      return Math.floor(Math.random() * Math.floor(max)) + 1;
   }
   
   function builder(number){
      let div = document.createElement('div');
      
      let diceArray = dice[number-1];
      for(let x = 1; x < 10; x++){
         let new_dot = document.createElement('div');
         new_dot.setAttribute('class', 'dot');
         if(diceArray.includes(x)){
            new_dot.classList.add('black');
         }else{
            new_dot.classList.add('white');
         }
         div.appendChild(new_dot);
      }
      
      div.setAttribute('class', 'dicer');
      return div;
   }
   
   function updateOutput(element, number){
      let holder = builder(number);
      if(element.children[0]){
         element.children[0].remove();
      }
      element.appendChild(holder);
   }
   
   button.addEventListener('click', function(){
      let rols = [roll(6), roll(6)];
      let message = '';
      if(rols[0] == rols[1]){
         message = 'draw';
      }else if(rols[0] > rols[1]){
         message = 'player 1 wins';
      }else{
         message = 'player 2 wins';
      }
      output.innerHTML = message;
      updateOutput(player1, rols[0]);
      updateOutput(player2, rols[1]);
   });
   
   //using code of dice
   /*
   button.addEventListener('click', function(){
      let rols = [roll(6), roll(6)];
      let message = '';
      if(rols[0] == rols[1]){
         message = 'draw';
      }else if(rols[0] > rols[1]){
         message = 'player 1 wins';
      }else{
         message = 'player 2 wins';
      }
      output.innerHTML = message;
      player1.innerHTML = "&#" + (rols[0] + 9855) + ';';
      player2.innerHTML = "&#" + (rols[1] + 9855) + ';';
   });
   */
   
   console.log('app is loaded');   
});
