document.addEventListener('DOMContentLoaded', function(){
   const myArray = ['lion', 'cougar', 'bark'];
   
   myArray.forEach(function(item){
      let div = document.createElement('div');
      div.setAttribute('class', 'animal ' + item);
      div.innerText = item.toUpperCase();
      div.addEventListener('click', play_audio);
      document.body.appendChild(div);
   });
   
   function play_audio(){
      let animal = this.innerHTML.toLowerCase();
      const animal_sound = new Audio('sounds/' + animal + '.mp3');
      animal_sound.addEventListener('loadeddata', function(){
         this.play();
      });
      addStyle(animal);
   }
   
   function addStyle(animal){
      let element = document.querySelector('.' + animal);
      element.classList.add('active');
      setTimeout(function(){
         element.classList.remove('active');
      }, 1000);
   }
   
   console.log('app is loaded');
});