let myBlock;
let myFunctionList;
let funList = [];
const movementArray = ['right', 'left', 'up', 'down'];

function getRandomHex(){
   return Math.random().toString(16).substr(-6);
}

function getRandomInt(max){
   return Math.floor(Math.random() * Math.floor(max));
}

function replaceAll(target, search, replacement){
   return target.replace(new RegExp(search, 'g'), replacement);
}

function addFun(value){
    let span = document.createElement('span');
    span.textContent = '++' + value;
    span.style.padding = '10px';
    span.style.border = '1px solid black';
    span.addEventListener('mouseover', function(){
      span.style.backgroundColor = 'red';
      span.style.color = 'white';
    });
    span.addEventListener('mouseout', function(){
      span.style.backgroundColor = 'white';
      span.style.color = 'black';
    });
    span.addEventListener('click', function(){
      let currentIndex = funList.indexOf(this);
      funList.splice(currentIndex, 1);
      myFunctionList.removeChild(this);
    });
    myFunctionList.appendChild(span);
    funList.push(span);
}

function mover(){
   if(funList.length > 0){
      
      let cur = myBlock.getBoundingClientRect();
      
      let element = funList.shift();
      myFunctionList.removeChild(element);
      let item_text = replaceAll(element.textContent, '\\+', '');
      myBlock.innerHTML = `Move ${item_text}`;
      
      switch(item_text){
         case 'left':
            myBlock.style.left = cur.left - cur.width + 'px';
            break;
         case 'right':
            myBlock.style.left = cur.left + cur.width + 'px';
            break;
         case 'up':
            myBlock.style.top = cur.top - cur.height + 'px';
            break;
         case 'down':
            myBlock.style.top = cur.top + cur.height + 'px';
            break;
         default:
            break;
      }
      
      setTimeout(mover, 300);
   }else{
      myBlock.innerHTML = 'Set path';
      return;
   }
}

document.addEventListener("keydown", function(e){
   e.preventDefault();
   let key = e.keyCode;
   switch(key){
      case 37:
         addFun('left');
         break;
      case 38:
         addFun('up');
         break;
      case 39:
         addFun('right');
         break;
      case 40:
         addFun('down');
         break;
      case 67: //c
         myBlock.style.background = '#' + getRandomHex();
         break;
      case 13:
      case 32:
         mover();
         break;
      default:
         random_move = movementArray[getRandomInt(movementArray.length)];
         addFun(random_move);
         break;
   }
});


document.addEventListener('DOMContentLoaded', function(){
   
   myBlock = document.createElement('div');
   myBlock.textContent = 'hello world';
   myBlock.style.width = '100px';
   myBlock.style.height = '100px';
   myBlock.style.backgroundColor = 'red';
   myBlock.style.color = 'white';
   myBlock.style.lineHeight = '100px';
   myBlock.style.textAlign = 'center';
   myBlock.style.position = 'absolute';
   myBlock.style.top = '100px';
   myBlock.style.left = '150px';
   document.body.appendChild(myBlock);
   
   myFunctionList = document.createElement('div');
   document.body.appendChild(myFunctionList);
   
   console.log('app is loaded');
});