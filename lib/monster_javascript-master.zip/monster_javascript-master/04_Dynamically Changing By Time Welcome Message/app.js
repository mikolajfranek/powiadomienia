document.addEventListener("DOMContentLoaded", function(){
   const button = document.querySelector('button');
   const output = document.querySelector('.output');
   button.addEventListener('click', function(){
      let time = new Date().getHours();
      let message = '';
      if(time > 17){
         message = 'It is evening';
         output.style.cssText = 'background:orange';
      }else if(time > 12){
         message = 'It is afternoon';
         output.setAttribute('style', 'background:yellow');
      }else if(time > 6){
         message = 'It is morning';
         output.style.backgroundColor = 'blue';
      }else if(time > 0){
         message = 'It is night';
         output.style.backgroundColor = 'black';
      }else{
         message = 'Something is wrong';
         output.style.backgroundColor = 'red';
      }
      output.innerHTML = message;
   });
   console.log('app is loaded');
});