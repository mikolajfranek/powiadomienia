//begin of changing html element
document.querySelector("h1").innerHTML = "Wow that was easy"; //only select one element

//different selectors for elements
console.log(document.getElementById("myID"));
console.log(document.querySelector("#myID"));
console.log(document.querySelector(".first"));
console.log(document.querySelector("div"));
document.querySelector("span").style.backgroundColor = "yellow";
document.querySelector(".first span").style.backgroundColor = "blue";
document.querySelector("li:first-child").style.backgroundColor = "red";
document.querySelector("li:last-child").style.backgroundColor = "green";
document.querySelector("li:nth-child(2)").style.backgroundColor = "purple";

//get elements by clsssname as htmlcollection
let elementList = document.getElementsByClassName("myClass"); //return multiply elements [object HTMLCollection]
console.log(elementList);

//iterate htmlcollection and nodelist
elementList = document.getElementsByTagName("span"); //[object HTMLCollection]
console.log(elementList);
for(let w = 0; w < elementList.length; w++){
    elementList[w].innerHTML = "Updated span method_two " + (w+1) + "<br/>";
}
elementList = document.querySelectorAll("span"); //foreach only work for nodelist [object Nodelist]
console.log(elementList);
elementList.forEach(function(item, index){
    //console.log(item, index);
    item.textContent = "Updated span " + (index + 1); //<br/> is not working, only textContent
});

//change feature of html element
const el1 = document.querySelector("#one");
console.log(el1);
el1.textContent = "Hello <br/> other side"; //<br/> is not interpreted as html
el1.innerText = "more text <br/>"; //<br/> is not interpreted as html
el1.innerHTML = "Good <br/> world"; //<br/> is interpreted as html
el1.style.color = "red";
el1.style.background = "blue";
//remove element #one
el1.remove();

const liItems = document.querySelectorAll("li");
liItems.forEach(function(item, index){
   item.textContent = "list item #" + index;
   item.id = index;
   //setAttribute
   item.setAttribute("class", "test test" + index);
   item.setAttribute("name", "name" + index);
   item.setAttribute("disabled", "");
   item.setAttribute("tag", "tag" + index);
   console.log(item.getAttribute("class"));
   console.log(item.className);
   //classes
   if(item.classList.contains('test')){
      console.log(`item ${index} has class test`);
   }
   item.classList.add('thisClass');
   item.classList.add('thisClass1');
   item.classList.remove('test');
   item.classList.toggle('anotherClass');
   item.classList.replace('thisClass1', 'endClass');
});
const ele1 = document.getElementsByTagName('a'); //return multiply elements
console.log(ele1);
let temp = ele1[0].getAttribute("href");
console.log(temp);
ele1[0].setAttribute("href", "https://onet.pl");

//change order of src 
const ele2 = document.getElementsByTagName("img");
let tempimg0 = ele2[0].getAttribute("src");
let tempimg1 = ele2[1].getAttribute("src");
ele2[0].setAttribute("src", tempimg1);
ele2[1].setAttribute("src", tempimg0);

//change href of all 'a element'
ele1_new = document.querySelectorAll("a");
ele1_new.forEach(function(item, index){
   item.setAttribute("href", "https://www.google.pl#" + index);
});

//children and traversing
let my_element = document.querySelector(".second"); //[object Nodelist]
for(let i = 0; i < my_element.children.length; i++){ //it is difference beteen this two for loop 
   console.log(my_element.children[i].textContent);  
}
my_element.childNodes.forEach(function(item){
   if(item.tagName){
      if(item.tagName.toLowerCase() == "li"){
         console.log(item.getAttribute("name"));
      }
   }
});
console.log(my_element.childNodes);
console.log(my_element.parentNode);
console.log(my_element.parentElement);
console.log(my_element.nextElementSibling);
console.log(my_element.nextSibling); //it is \n - it is not element of html, but new line
console.log(my_element.previousElementSibling);
console.log(my_element.previousSibling); //it is \n - it is not element of html, but new line

//styling
const new_element = document.getElementsByClassName('thisClass');
let tempElem = new_element[3];
tempElem.style.backgroundColor = "green";
tempElem.style.color = "white";
tempElem.style.border = "5px dotted purple";
tempElem.style.fontSize = "40px";
tempElem.style.display = "none";
tempElem.style.display = "block";
tempElem.style.padding = "35px";

//create elements
document.body.onload = addElement;
function addElement(){
   var new_div = document.createElement("div");
   var new_content = document.createTextNode("Hi there and greetings");
   new_div.appendChild(new_content);
   var current_div = document.getElementById("myID");
   document.body.insertBefore(new_div, current_div);
}

//events listeners
const ul_element = document.querySelector("ul");
ul_element.addEventListener("click", function(){
   console.log("Click ul");
   this.style.backgroundColor = "yellow";
});
const li_element = document.querySelectorAll("li");
li_element.forEach(function(item){
   item.addEventListener("click", make_it_red);
});
function make_it_red(){
   console.log("Click li");
   this.classList.toggle("red");
   this.style.color = "red";
}

//image 'popup'
const img_elemnt = document.querySelectorAll("img");
img_elemnt.forEach(function(item, index){
   item.onclick = (function(){
      window.open(this.src, `my image${index}`, 'resizable=yes, scrollbars=yes, width=500, height=500');
   });
});

//listitems
main_element = document.querySelector(".second");
input_element = document.querySelector("input");
clicker_element = document.getElementById("clicker");
clicker_element.addEventListener("click", function(){
   if(input_element.value.length > 3){
      newer_element = document.createElement("li");
      content_elment = document.createTextNode(input_element.value);
      newer_element.appendChild(content_elment);
      main_element.appendChild(newer_element);      
   }
});

//backgroundcolor
button_element = document.querySelector('.bg');
button_element.addEventListener("click", function(event){
   let my_color = `rgb(${random(255)}, ${random(255)}, ${random(255)})`;
   document.body.style.backgroundColor = my_color;
   
   console.log(event);
   console.log(event.target);
   console.log(this); //the same as event.target
   
});
function random(number){
   return Math.floor(Math.random() * (number));
}

//backgroundcolor for many elements
divs_element = document.querySelectorAll('div');
divs_element.forEach(function(item){
   item.addEventListener("click", function(event){
      let my_color = `rgb(${random(255)}, ${random(255)}, ${random(255)})`;
      event.target.style.background = my_color;
   });
});

//key event
let keys ={
   ArrowUp: false,
   ArrowDown: false,
   ArrowLeft: false,
   ArrowRight: false
};
document.addEventListener("keydown", pressKeyOn);
document.addEventListener("keyup", pressKeyOff);
function pressKeyOn(event){
   //console.log(event.key);
   //event.preventDefault(); //stoping default behavior
   keys[event.key] = true;
   console.log(keys);
}
function pressKeyOff(event){
   //console.log(event.key);
   //event.preventDefault(); //stoping default behavior
   keys[event.key] = false;
   console.log(keys);
}

//key press
const element_input = document.querySelector("input");
element_input.addEventListener("keypress", addItem);
function addItem(event){
   console.log(event);
   document.querySelector("h1").textContent = element_input.value + event.key;
   if(element_input.value.length > 5){
      element_input.style.backgroundColor = "red";
   }else{
      element_input.style.backgroundColor = "white";
   }
   if(event.keyCode === 13 && element_input.value.length > 1){
      document.querySelector("h1").style.backgroundColor = "yellow";
   }
}

//add element to list
const ul = document.querySelector("ul");
document.addEventListener("keydown", function(e){
   let li = document.createElement("li");
   let temp = e.key + "(" + e.keyCode + ")";
   let textContent = document.createTextNode(temp);
   li.appendChild(textContent);
   ul.appendChild(li);
});

//mouse events
const element_list = document.querySelectorAll("li");
element_list.forEach(function(item){
   item.addEventListener("mouseenter", function(event){
      this.classList.add("red");
      setTimeout(function(){
         event.target.classList.remove("red");
      }, 500);
   });
   
   item.addEventListener("mouseleave", function(event){
      this.classList.add("red");
      setTimeout(function(){
         event.target.classList.remove("red");
      }, 500);
   });
   //mouseleave, mouseenter - it is executed for each element
   //mouseover, mouseout - event is sent to the deepest element of dom tree (check specification)
   item.addEventListener("mouseover", function(){
      this.style.backgroundColor = "blue";
      console.log("mouseover");
   });
   item.addEventListener("mouseout", function(){
      this.style.backgroundColor = "yellow";
      console.log("mouseout");
   });
});

//chalange list
const inputSelect = document.querySelector('input[name="newItem"]');
const mainList = document.querySelector("#mainList"); //ul
for(let i = 0; i < mainList.children.length; i++){
   mainList.children[i].addEventListener("click", makeNew);
}
inputSelect.addEventListener("keypress", function(event){
   if(event.keyCode === 13){
      let newLi = document.createElement("li");
      newLi.addEventListener("click", makeNew);
      let newCon = document.createTextNode(inputSelect.value);
      inputSelect.value = "";
      newLi.appendChild(newCon);
      mainList.appendChild(newLi);
   }
});
function makeNew(){
   let temp = this.classList.toggle("green");
   if(temp){
      let span = document.createElement("span");
      span.textContent = " X ";
      span.addEventListener("click", function(){
         this.parentElement.remove();
      });
      this.appendChild(span); //add only X to li
   }else{
      this.getElementsByTagName("span")[0].remove();
   }
}

//capture bubble
const outputElement = document.getElementById("output");
const dives = document.querySelectorAll(".caputure_bubble");

function output(msg){outputElement.innerHTML += (`${msg} <br/>`);}
function capture(){output('capture: ' + this.v);}
function bubble(){output('bubble: ' + this.v);}

dives.forEach(function(item, index){
   console.log(index);
   item.style.border = "1px solid red";
   item.style.width = "100px";
   item.style.padding = "10px";
   item.v = (index + 1);
   item.addEventListener("click", capture, true);
   item.addEventListener("click", bubble, false);
});